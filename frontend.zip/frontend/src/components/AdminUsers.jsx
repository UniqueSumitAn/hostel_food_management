import React from 'react'

const AdminUsers = () => {
  return (
    <div>
      Users
    </div>
  )
}

export default AdminUsers
