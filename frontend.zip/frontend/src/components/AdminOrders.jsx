import React from 'react'

const AdminOrders = () => {
  return (
    <div>
      Orders
    </div>
  )
}

export default AdminOrders
