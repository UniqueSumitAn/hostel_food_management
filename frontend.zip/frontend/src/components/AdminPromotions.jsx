import React from 'react'

const AdminPromotions = () => {
  return (
    <div>
      Promotions
    </div>
  )
}

export default AdminPromotions
