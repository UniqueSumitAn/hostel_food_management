import React from 'react'

const AdminSettings = () => {
  return (
    <div>
      Settings
    </div>
  )
}

export default AdminSettings
